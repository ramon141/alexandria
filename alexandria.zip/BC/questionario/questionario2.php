<html>
    <head>
        <meta charset="utf-8">
        <title>Teste</title>
    </head>
    <body>
    <div>
		<form>
			<fieldset style="width: 580px; height: 270px;">
				<div>
					<p> Responda esse questionário sobre o que voce estudou.</p>
					<div>                     
						<textarea style="width: 500px; height: 90px;" id="textarea" name="textarea">QUESTÃO</textarea>
					</div>
				</div><br>
				<div class="form-group">
					<div class="col-md-4">
						<div class="radio">
							<label for="radios-1">
								<input type="radio" name="radios" id="option-A" value="1" checked="checked">
								a) Option two
							</label>
						</div>
						<div class="radio">
							<label for="radios-1">
								<input type="radio" name="radios" id="option-B" value="2">
								b) Option two
							</label>
						</div>
					</div>
				</div><br>
				<div class="form-group">
					<div class="col-md-12">
						<button id="button1id" name="button1id" class="btn btn-success">Responder</button>
					</div>
				</div>

			</fieldset>
		</form>
	</div>
    </body>
</html>
