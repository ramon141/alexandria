<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="check.css">
	</head>
	<body>
		<fieldset style="border: none;">
			<form id="questionario" name ="nome do questionario" method="post" action="resposta.php">

				<h3 style="border-radius: 10px; padding: 10px; width: 30%; background-color: powderblue;"> 1) De acordo com o estudo do texto que acabamos de lê, assinale o que ele representa: </h3>

				<label class="container"> A) resposta1
	  				<input type="radio" name="questao1" >
	  				<span class="checkmark"></span>
				</label><br>
                                
                                
                                
				<label class="container"> B) resposta2
	  				<input type="checkbox" name="questao2" >
	  				<span class="checkmark"></span>
				</label><br>
				<label class="container"> C) resposta3
	  				<input type="checkbox" name="questao3" checked="checked" >
	  				<span class="checkmark"></span>
				</label><br>
				<label class="container"> D) resposta4
	  				<input type="checkbox">
	  				<span class="checkmark" name="questao4"></span>
				</label><br><br>
				<button style="background-color: powderblue;  color: white; padding: 10px; width: 100px; border: none; text-align: center; font-size: 16px; cursor: pointer;">Enviar</button>
			</form>
		</fieldset>
		<fieldset style="border: none;">
			<form id="questionario" name ="nome do questionario" method = "post" action="resposta.php">

				<h3 style="border-radius: 10px; padding: 10px; width: 30%; background-color: powderblue;"> 2) De acordo com o estudo do texto que acabamos de lê, assinale o que ele representa: </h3>

				<label class="container"> A) resposta1
	  				<input type="checkbox" name="questao1" >
	  				<span class="checkmark"></span>
				</label><br>
				<label class="container"> B) resposta2
	  				<input type="checkbox" name="questao2" >
	  				<span class="checkmark"></span>
				</label><br>
				<label class="container"> C) resposta3
	  				<input type="checkbox" name="questao3" >
	  				<span class="checkmark"></span>
				</label><br>
				<label class="container"> D) resposta4
	  				<input type="checkbox">
	  				<span class="checkmark" name="questao4"></span>
				</label><br><br>
				<button style="background-color: powderblue;  color: white; padding: 10px; width: 100px; border: none; text-align: center; font-size: 16px; cursor: pointer;">Enviar</button>
			</form>
		</fieldset>
		<fieldset style="border: none;">
			<form id="questionario" name ="nome do questionario" method = "post" action="resposta.php">

				<h3 style="border-radius: 10px; padding: 10px; width: 30%; background-color: powderblue;"> 3) De acordo com o estudo do texto que acabamos de lê, assinale o que ele representa: </h3>

				<label class="container"> A) resposta1
	  				<input type="checkbox" name="questao1" >
	  				<span class="checkmark"></span>
				</label><br>
				<label class="container"> B) resposta2
	  				<input type="checkbox" name="questao2" >
	  				<span class="checkmark"></span>
				</label><br>
				<label class="container"> C) resposta3
	  				<input type="checkbox" name="questao3" >
	  				<span class="checkmark"></span>
				</label><br>
				<label class="container"> D) resposta4
	  				<input type="checkbox">
	  				<span class="checkmark" name="questao4"></span>
				</label><br><br>
				<button style="background-color: powderblue;  color: white; padding: 10px; width: 100px; border: none; text-align: center; font-size: 16px; cursor: pointer;">Enviar</button>
			</form>
		</fieldset>
	</body>
</hmtl>