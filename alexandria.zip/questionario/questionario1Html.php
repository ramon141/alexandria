<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="style.css">
	</head>
	<body>
		<form id="questionario" name ="nome do questionario" method = "post" action="resposta.php">
			<p> 1) De acordo com o estudo do texto que acabamos de lê, assinale o que ele representa:</p>

			<label><input type="radio" name="questao1" value="a" /> A) resposta1;</label>
			<br/>
			<label><input type="radio" name="questao1" value="b" /> B) resposta2;</label>
			<br/>
			<label><input type="radio" name="questao1" value="c" /> C) resposta3;</label>
			<label><input type="radio" name="questao1" value="d" /> D) resposta4.</label>
			<br/><br/>
		</form>
		<form id="questionario" name ="nome do questionario" method = "post" action="resposta.php">
			<p> 2) De acordo com o estudo do texto que acabamos de lê, assinale o que ele representa:</p>
			<label>	<input type="radio" name="questao1" value="a" /> A) resposta1;</label>
			<br/>
			<label><input type="radio" name="questao1" value="b" /> B) resposta2;</label>
			<br/>
			<label><input type="radio" name="questao1" value="c" /> C) resposta3;</label>
			<br/>
			<label><input type="radio" name="questao1" value="d" /> D) resposta4.</label>
			<br/><br/>
		</form>
		<form id="questionario" name ="nome do questionario" method = "post" action="resposta.php">
			<p>3) De acordo com o estudo do texto que acabamos de lê, assinale o que ele representa:</p>
			<label><input type="radio" name="questao1" value="a" /> A) resposta1;</label>
			<br/>
			<label><input type="radio" name="questao1" value="b" /> B) resposta2;</label>
			<br/>
			<label><input type="radio" name="questao1" value="c" /> C) resposta3;</label>
			<br/>
			<label><input type="radio" name="questao1" value="d" /> D) resposta4.</label>
			<br/><br/>

	</body>
</hmtl>