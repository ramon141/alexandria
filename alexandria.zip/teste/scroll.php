<html>
<head>
<style>
 
::-webkit-scrollbar {
    width: 12px;
}
  
::-webkit-scrollbar-thumb {
    -webkit-border-radius: 10px;
    border-radius: 10px;
    background: rgba(0,0,255,0.8); 
    -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.5); 
}
 
</style>
</head>
<body>
 
<textarea cols="7" rows="10">
This is a paragraph
This is a paragraph
This is a paragraph
This is a paragraph
This is a paragraph
This is a paragraph
This is a paragraph
</textarea>
 
</body>
</html>