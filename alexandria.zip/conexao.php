<?php
$connection = mysqli_connect('localhost', '83840', 'alexandria1', '83840');
$connection->set_charset("utf8");